package to;

import java.io.Serializable;

public class CardapioTO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private int numero;
	private String descricao;
	private double valorUnit;
	private boolean dispPrato;
	
	
	
	public int getNumero() {
		return numero;
	}
	
	public void setNumero(int numero) {
		this.numero = numero;
	}
	
	public String getDescricao() {
		return descricao;
	}
	
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	public double getValorUnit() {
		return valorUnit;
	}
	
	public void setValorUnit(double valorUnit) {
		this.valorUnit = valorUnit;
	}
	
	public boolean isDispPrato() {
		return dispPrato;
	}
	
	public void setDispPrato(boolean dispPrato) {
		this.dispPrato = dispPrato;
	}
}
