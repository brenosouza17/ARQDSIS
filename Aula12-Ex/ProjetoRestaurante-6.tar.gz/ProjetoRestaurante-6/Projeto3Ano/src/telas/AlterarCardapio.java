package telas;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ResourceBundle;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import service.CardapioService;
import to.CardapioTO;

public class AlterarCardapio extends JDialog implements ActionListener {
	
	private JPanel pn1, pn2, pn3, pn4;
	private JLabel lb1, lb2, lb3, lb4;
	private JButton but1, but2, but3;
	private JTextArea area;
	private JTextField txt1, txt2, txt3, txt4;
	private ResourceBundle bn = ResourceBundle.getBundle("ex1",Internacionalizar.local);
	
	public AlterarCardapio()
	{
		setModal(true);
		setTitle(bn.getString("p48"));
		
		Container cont1 = getContentPane();
		cont1.setLayout(new GridLayout(4,1));
		
		pn1 = new JPanel();
		pn1.setLayout(new GridLayout(1,3));
		
		pn2 = new JPanel();
		pn2.setLayout(new FlowLayout());
		
		pn3 = new JPanel();
		pn3.setLayout(new GridLayout(3,2));
		
		pn4 = new JPanel();
		pn4.setLayout(new GridLayout(1,6,50,50));
		
		//JLABELS
		lb1 = new JLabel(bn.getString("p49"));
		lb2 = new JLabel(bn.getString("p50"));
		lb3 = new JLabel(bn.getString("p51"));
		lb4 = new JLabel(bn.getString("p52"));
		
		//JAREA
		area = new JTextArea();
		
		//BOT�ES
		but1 = new JButton(bn.getString("p53"));
		but2 = new JButton(bn.getString("p54"));
		but3 = new JButton(bn.getString("p55"));
		
		but1.addActionListener(this);
		but2.addActionListener(this);
		but3.addActionListener(this);
		
		//TEXT FIELDS
		txt1 = new JTextField(10);
		txt2 = new JTextField(10);
		txt3 = new JTextField(10);
		txt4 = new JTextField(10);
		
		/*
		txt4.setVisible(false);
		txt4.setEditable(false);
		txt5.setVisible(false);
		txt5.setVisible(false);*/
		
		//PAINEL 1
		pn1.add(lb1);
		pn1.add(txt1);
		pn1.add(but1);
		
		cont1.add(pn1);
		
		//PAINEL 2
		pn2.add(area);
		cont1.add(pn2);
		
		//PAINEL 3
//		pn3.add(lb2);
//		pn3.add(txt2);
		pn3.add(lb3);
		pn3.add(txt3);
		pn3.add(lb4);
		pn3.add(txt4);
		
		cont1.add(pn3);
		
		//PAINEL 4
		pn4.add(but3);
		pn4.add(but2);
		
		cont1.add(pn4);
		
		setLocation(300,100);
	    setSize(665,600);
	    setVisible(true);
	      
	    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
	}//FIM DO CONTRUTOR
	
	public void actionPerformed(ActionEvent e)
	{
		try
		{
			if(e.getSource() == but1)
			{
				CardapioService ca = new CardapioService();
				CardapioTO to = new CardapioTO();
				to.setNumero(Integer.parseInt(txt1.getText()));
				//CardapioDAO card = new CardapioDAO();
				ca.consultar(to);
				
				if(to.getDescricao() != null)
				{
					area.setText(to.getNumero()+" "+to.getDescricao()+" "+to.getValorUnit());
				}
			}
			if(e.getSource() == but2)
			{
				CardapioService ca = new CardapioService();
				CardapioTO to = new CardapioTO();
				to.setNumero(Integer.parseInt(txt1.getText()));
				to.setValorUnit(Double.parseDouble(txt3.getText()));
				to.setDescricao(txt4.getText());
				
				//CardapioDAO card = new CardapioDAO();
				ca.alterar(to);
			}
			if(e.getSource() == but3)
			{
				this.dispose();
			}
		}
		catch(Exception ex)
		{
			JOptionPane.showMessageDialog(null,"Erro de opera��o");
		}
	}//ActionPerformed
	
	public static void main(String args[])
	{
		AlterarCardapio men = new AlterarCardapio();
	}
}//FIM DA CLASSE
