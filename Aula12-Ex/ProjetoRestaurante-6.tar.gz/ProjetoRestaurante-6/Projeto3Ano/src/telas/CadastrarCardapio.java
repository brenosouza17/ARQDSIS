package telas;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ResourceBundle;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import service.CardapioService;
import to.CardapioTO;

public class CadastrarCardapio extends JDialog implements ActionListener {
	
	private JPanel pn1, pn2;
	private JLabel lb1, lb2, lb3;
	private JButton but1, but2;
	private JTextField txt1, txt2, txt3;
	
	private ResourceBundle bn = ResourceBundle.getBundle("ex1",Internacionalizar.local);
	
	public CadastrarCardapio()
	{
		setModal(true);
		setTitle(bn.getString("p42"));
		
		Container cont1 = getContentPane();
		cont1.setLayout(new GridLayout(2,1,50,0));
		
		pn1 = new JPanel();
		pn1.setLayout(new GridLayout(3,2));		
		
		pn2 = new JPanel();
		pn2.setLayout(new GridLayout(1,2,20,20));

		//JLABELS
		lb1 = new JLabel(bn.getString("p43"));
		lb2 = new JLabel(bn.getString("p44"));
		lb3 = new JLabel(bn.getString("p45"));
      
      
      //TEXT FIELDS
      txt1 = new JTextField(10);
      txt2 = new JTextField(10);
      txt3 = new JTextField(10);
      
      
				
		//BOT�ES
      	but1 = new JButton(bn.getString("p46"));
		but2 = new JButton(bn.getString("p47"));
		
		//A��O AOS BOT�ES
		but1.addActionListener(this);
		but2.addActionListener(this);
		
			//PAINEL 1
		pn1.add(lb1);
		pn1.add(txt1);
		pn1.add(lb2);
		pn1.add(txt2);
		pn1.add(lb3);
		pn1.add(txt3);
	
		cont1.add(pn1);
		
		//PAINEL 2
      pn2.add(but2);
      pn2.add(but1);
		
      cont1.add(pn2);
		
		setLocation(650,420);
	   setSize(500,180);
	   setVisible(true);
	      
	   setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
	}//FIM DO CONTRUTOR
	
	public void actionPerformed(ActionEvent e)
	{
		try
		{
			if(e.getSource() == but1)
			{
				CardapioService ca = new CardapioService();
				CardapioTO to = new CardapioTO();
				to.setNumero(Integer.parseInt(txt1.getText()));
				to.setValorUnit(Double.parseDouble(txt2.getText()));
				to.setDescricao(txt3.getText());
				//CardapioDAO card = new CardapioDAO();
				ca.criar(to);
			}
			if(e.getSource() == but2)
			{
				this.dispose();
			}
			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}//ActionPerformed
	
	public static void main(String args[])
	{
		CadastrarCardapio men = new CadastrarCardapio();
	}
}//FIM DA CLASSE
