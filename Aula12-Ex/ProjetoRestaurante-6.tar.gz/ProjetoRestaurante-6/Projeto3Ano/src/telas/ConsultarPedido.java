package telas;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ResourceBundle;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import service.PedidoService;
import to.PedidoTO;

public class ConsultarPedido extends JDialog implements ActionListener {

	private JPanel pn1, pn2, pn3;
	private JLabel lb1;
	private JButton but1;
	private JTextField txt1, txt2, txt3, txt4;
	private JTextArea area;

	private ResourceBundle bn = ResourceBundle.getBundle("ex1", Internacionalizar.local);

	public ConsultarPedido() {
		setModal(true);
		setTitle(bn.getString("p24"));

		Container cont1 = getContentPane();
		cont1.setLayout(new GridLayout(3, 1));

		pn1 = new JPanel();
		pn1.setLayout(new GridLayout(1, 2));

		pn2 = new JPanel();
		pn2.setLayout(new FlowLayout());

		pn3 = new JPanel();
		pn3.setLayout(new GridLayout(1, 4));

		// JLABELS
		lb1 = new JLabel(bn.getString("p25"));

		// BOT�ES
		but1 = new JButton(bn.getString("p26"));

		but1.addActionListener(this);

		// JAREA
		area = new JTextArea();
		
		// TEXT FIELDS
		txt1 = new JTextField(10);
		txt2 = new JTextField(10);
		txt3 = new JTextField(10);
		txt4 = new JTextField(10);
		
		Action action = new AbstractAction()
		{
		    @Override
		    public void actionPerformed(ActionEvent e)
		    {
		    	PedidoTO pod = new PedidoTO();
				PedidoService pdao = new PedidoService();
				
				pod.setNumero(Integer.parseInt(txt1.getText()));
				
				pdao.consultar3(pod);
				
				area.setText("N�mero: "+pod.getNumero() + "\n Mesa: " + pod.getMesa() + "\n Data Entrada: " + pod.getEntrada() + "\n Data Sa�da: " + pod.getSaida() + "\n Gar�om: " + pod.getGarcom());
				
		    }
		};
		
		txt1.addActionListener(action);

		txt2.setVisible(false);
		txt2.setEditable(false);
		txt3.setVisible(false);
		txt3.setVisible(false);
		txt4.setVisible(false);
		txt4.setVisible(false);

		// PAINEL 1
		pn1.add(lb1);
		pn1.add(txt1);

		cont1.add(pn1);

		// PAINEL 2
		pn2.add(area);
		cont1.add(pn2);

		// PAINEL 3
		pn3.add(but1);
		pn3.add(txt2);
		pn3.add(txt3);
		pn3.add(txt4);

		cont1.add(pn3);

		setLocation(500, 300);
		setSize(665, 600);
		setVisible(true);

		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

	}// FIM DO CONTRUTOR

	public void actionPerformed(ActionEvent e) {
		try {
			if (e.getSource() == but1) {
				this.dispose();
			}
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(null, "ERRO");
		}
	}// ActionPerformed

	public static void main(String args[]) {
		ConsultarPedido men = new ConsultarPedido();
	}
}// FIM DA CLASSE
