package telas;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ResourceBundle;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class HorarioPico extends JDialog implements ActionListener {
	
	private JPanel pn1, pn2, pn3;
	private JLabel lb1;
	private JButton but1, but2;
	private JTextField txt1;
	private ResourceBundle bn = ResourceBundle.getBundle("ex1",Internacionalizar.local);
	
	public HorarioPico()
	{
		setModal(true);
		setTitle(bn.getString("p64"));
		
		Container cont1 = getContentPane();
		cont1.setLayout(new GridLayout(3,1));
		
		pn1 = new JPanel();
		pn1.setLayout(new GridLayout(1,2,10,10));		
		
      pn2 = new JPanel();
		pn2.setLayout(new FlowLayout());
		
		pn3 = new JPanel();
		pn3.setLayout(new GridLayout(1,2,10,10));
		
		//JLABELS
		lb1 = new JLabel(bn.getString("p65"));
      
      //TEXT FIELDS
		txt1 = new JTextField(10);
      
      
				
		//BOT�ES
		but1 = new JButton(bn.getString("p66"));
		but2 = new JButton(bn.getString("p67"));
		
		//A��O AOS BOT�ES
		but1.addActionListener(this);
		but2.addActionListener(this);
		
			//PAINEL 1
		pn1.add(lb1);
		pn1.add(txt1);
      pn1.add(but1);
	
		cont1.add(pn1);
		
		//PAINEL 2
		cont1.add(pn2);
		
		//PAINEL 3
		pn3.add(but2);
      
      
		
		
		
		cont1.add(pn3);
		
		setLocation(400,100);
	   setSize(665,300);
	   setVisible(true);
	      
	   setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
	}//FIM DO CONTRUTOR
	
	public void actionPerformed(ActionEvent e)
	{
		try
		{
			if(e.getSource() == but1)
			{
				
			}
			if(e.getSource() == but2)
			{
				this.dispose();
			}
			
		}
		catch(Exception ex)
		{
			JOptionPane.showMessageDialog(null,"ERRO");
		}
	}//ActionPerformed
	
	public static void main(String args[])
	{
		HorarioPico men = new HorarioPico();
	}
}//FIM DA CLASSE
