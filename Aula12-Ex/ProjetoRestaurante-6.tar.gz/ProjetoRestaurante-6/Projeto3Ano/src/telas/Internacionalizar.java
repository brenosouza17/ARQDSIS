package telas;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Internacionalizar extends JFrame implements ActionListener{
	
	JPanel painel;
	JButton b1, b2, b3;
	JLabel label;
	static Locale local = Locale.US;

	public Internacionalizar()
	{
		super("Sistema Restaurante/Restaurant System/El Sistema De Restaurantes");
	}
	
	public void idioma()
	{
		 Container cont1 = getContentPane();
       
       cont1.setLayout(new GridLayout(1,3,50,50));
       
       painel = new JPanel();
	    painel.setLayout(new GridLayout());
       
       cont1.add(painel);
	    
	    label = new JLabel("       Idioma / Idiom:");
	    
	    b1 = new JButton("Portugu�s");
	    b2 = new JButton("English");
	    b3 = new JButton("Espa�ol");
       
       b1.setBackground( new Color(46,139,87));
       b1.setForeground( new Color(238,238,0));
       
       b2.setBackground( new Color(59,89,152));
       b2.setForeground( new Color(205,0,0));
       
       b3.setBackground( new Color(255,0,0));
       b3.setForeground( new Color(255,215,0));
       
       b1.setFont(new Font("TimesRoman",Font.BOLD,14));
       b2.setFont(new Font("TimesRoman",Font.BOLD,14));
       b3.setFont(new Font("TimesRoman",Font.BOLD,14));
       
	    
	    painel.add(label);
	    painel.add(b1);
	    painel.add(b2);
	    painel.add(b3);
	    
	    b1.addActionListener(this);
	    b2.addActionListener(this);
	    b3.addActionListener(this);
	    
       getContentPane().add(painel);
	    setDefaultCloseOperation(EXIT_ON_CLOSE);
	    setSize(530, 100);
	    setVisible(true);
	    setLocation(650,420);
	}
	
	public static void main(String[] args)
	{
	      Internacionalizar in = new Internacionalizar();
	      in.idioma();
	      
	     
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource() == b1)
		{
			
			
			Internacionalizar.local=new Locale("pt","BR");
			System.out.println(Internacionalizar.local.toString());
			 MenuPrincipal tela0 = new MenuPrincipal();
			 this.dispose();
			 
		}
		if(e.getSource() == b2)
		{
			
			
			Internacionalizar.local=Locale.US;
			System.out.println(Internacionalizar.local.toString());
			 MenuPrincipal tela0 = new MenuPrincipal();
			 this.dispose();
			 
		}
		if(e.getSource() == b3)
		{
			
			
			Internacionalizar.local=new Locale("es","ES");
			System.out.println(Internacionalizar.local.toString());
			 MenuPrincipal tela0 = new MenuPrincipal();
			 this.dispose();
			 
		}
	}
}
