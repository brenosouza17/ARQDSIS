package telas;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ResourceBundle;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class CartaoDebito extends JDialog implements ActionListener {

	private JPanel pn1, pn2;
	private JLabel lb1, lb2;
	private JButton but1, but2;
	private JTextField txt1, txt2;
	private ResourceBundle bn = ResourceBundle.getBundle("ex1", Internacionalizar.local);

	public CartaoDebito() {
		setModal(true);
		setTitle(bn.getString("p107"));

		Container cont1 = getContentPane();
		cont1.setLayout(new GridLayout(2, 1));

		pn1 = new JPanel();
		pn1.setLayout(new GridLayout(2, 2));

		pn2 = new JPanel();
		pn2.setLayout(new GridLayout(1, 2, 20, 20));

		// JLABELS
		lb1 = new JLabel(bn.getString("p108"));
		lb2 = new JLabel(bn.getString("p109"));

		// TEXT FIELDS
		txt1 = new JTextField(10);
		txt2 = new JTextField(10);
		txt2.setEditable(false);

		txt2.setText("R$ " + FecharConta.df.format(FecharConta.total));

		// BOT�ES
		but1 = new JButton(bn.getString("p110"));
		but2 = new JButton(bn.getString("p111"));

		// A��O AOS BOT�ES
		but1.addActionListener(this);
		but2.addActionListener(this);

		// PAINEL 1
		pn1.add(lb1);
		pn1.add(txt1);
		pn1.add(lb2);
		pn1.add(txt2);

		cont1.add(pn1);

		// PAINEL 2
		pn2.add(but1);
		pn2.add(but2);

		cont1.add(pn2);

		setLocation(650, 420);
		setSize(500, 180);
		setVisible(true);

		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

	}// FIM DO CONTRUTOR

	public void actionPerformed(ActionEvent e) {
		try {
			if (e.getSource() == but1) {
				this.dispose();
				FormaPagamento men = new FormaPagamento();
			}
			if (e.getSource() == but2) {
				this.dispose();
				JOptionPane.showMessageDialog(null, "Transa��o Completa!");
			}

		} catch (Exception ex) {
			JOptionPane.showMessageDialog(null, "ERRO");
		}
	}// ActionPerformed

	public static void main(String args[]) {
		CartaoDebito men = new CartaoDebito();
	}
}// FIM DA CLASSE
