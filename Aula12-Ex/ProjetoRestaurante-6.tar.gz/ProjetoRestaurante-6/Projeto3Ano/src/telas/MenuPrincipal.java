package telas;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ResourceBundle;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class MenuPrincipal extends JFrame implements ActionListener {

	private JButton b1, b2, b3, b4, b5, b6, b7, b8, b9, b10;
	private ResourceBundle bn = ResourceBundle.getBundle("ex1", Internacionalizar.local);
	private JPanel pn1, pn2, pn3;

	// Construtor
	public MenuPrincipal() {
		setTitle(bn.getString("titulo"));
		Container cont1 = getContentPane();

		cont1.setLayout(new GridLayout(3, 1, 40, 40));

		pn1 = new JPanel();
		pn1.setLayout(new GridLayout(1, 3, 40, 40));

		pn2 = new JPanel();
		pn2.setLayout(new GridLayout(1, 3, 40, 40));

		pn3 = new JPanel();
		pn3.setLayout(new GridLayout(1, 3, 40, 40));

		cont1.add(pn1);
		cont1.add(pn2);
		cont1.add(pn3);

		// Instanciando Bot�es

		b1 = new JButton(bn.getString("login"));
		b2 = new JButton(bn.getString("pedido"));
		b3 = new JButton(bn.getString("pratos"));
		b4 = new JButton(bn.getString("finalizar"));
		b5 = new JButton(bn.getString("horario"));
		b6 = new JButton(bn.getString("cardapio"));
		b7 = new JButton(bn.getString("conta"));
		b8 = new JButton(bn.getString("nf"));
		b9 = new JButton(bn.getString("sair"));

		/*
		 * b1.setFont(new Font("TimesRoman",Font.BOLD,14)); b2.setFont(new
		 * Font("TimesRoman",Font.BOLD,14)); b3.setFont(new
		 * Font("TimesRoman",Font.BOLD,14)); b4.setFont(new
		 * Font("TimesRoman",Font.BOLD,14)); b5.setFont(new
		 * Font("TimesRoman",Font.BOLD,14)); b6.setFont(new
		 * Font("TimesRoman",Font.BOLD,14)); b7.setFont(new
		 * Font("TimesRoman",Font.BOLD,14)); b8.setFont(new
		 * Font("TimesRoman",Font.BOLD,14)); b9.setFont(new
		 * Font("TimesRoman",Font.BOLD,14));
		 */

		// A��o aos bot�es

		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		b4.addActionListener(this);
		b5.addActionListener(this);
		b6.addActionListener(this);
		b7.addActionListener(this);
		b8.addActionListener(this);
		b9.addActionListener(this);

		b2.setEnabled(false);
		b3.setEnabled(false);
		b4.setEnabled(false);
		b5.setEnabled(false);
		b6.setEnabled(false);
		b7.setEnabled(false);
		b8.setEnabled(false);

		// Adicionando bot�es no Painel

		pn1.add(b1);
		pn1.add(b2);
		pn1.add(b3);

		pn2.add(b4);
		pn2.add(b5);
		pn2.add(b6);

		pn3.add(b7);
		pn3.add(b8);
		pn3.add(b9);

		setLocation(400, 100);
		setSize(690, 500);
		setVisible(true);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}// FIM DO CONSTRUTOR

	public void verificar() {
		if (Login.usuario == "" || Login.senha == "")
		{
			b2.setEnabled(false);
			b3.setEnabled(false);
			b4.setEnabled(false);
			b5.setEnabled(false);
			b6.setEnabled(false);
			b7.setEnabled(false);
			
		}
		else if (Login.cargo == "a")
		{
			b2.setEnabled(true);
			b3.setEnabled(true);
			b4.setEnabled(true);
			b5.setEnabled(true);
			b6.setEnabled(true);
			b7.setEnabled(true);
			b8.setEnabled(true);
		}
		else if (Login.cargo == "g")
		{
			b2.setEnabled(true);
		}
		else if (Login.cargo == "c")
		{
			b7.setEnabled(true);
		}
	}

	public void actionPerformed(ActionEvent evento) {
		System.out.println(evento.getSource());
		try {
			if (evento.getSource() == b1) {
				this.dispose();
				Login log = new Login();
				
			}
			if (evento.getSource() == b2) {
				Pedido ped = new Pedido();
			}
			if (evento.getSource() == b3) {
				PratosMaisVendidos pmv = new PratosMaisVendidos();
			}
			if (evento.getSource() == b4) {
				FinalizarPrato finPrat = new FinalizarPrato();
			}
			if (evento.getSource() == b5) {
				HorarioPico horPico = new HorarioPico();
			}
			if (evento.getSource() == b6) {
				Cardapio cardapio = new Cardapio();
			}
			if (evento.getSource() == b7) {
				FecharConta fechCont = new FecharConta();
			}
			if (evento.getSource() == b8) {
				FechamentoNF fechNF = new FechamentoNF();
			}
			if (evento.getSource() == b9) {
				System.exit(0);
			}
		} // FIM DO TRY
		catch (Exception ex) {
			JOptionPane.showMessageDialog(null, "ERRO");
		} // FIM DO CATCH

	}// FIM DO M�TODO ActionPerformed

	public static void main(String args[]) {
		MenuPrincipal tela1 = new MenuPrincipal();
	}

}// FIM DA CLASSE
