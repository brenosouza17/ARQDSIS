package telas;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ResourceBundle;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class FormaPagamento extends JDialog implements ActionListener {
	
   private JPanel pn1, pn2;
   private JButton but1, but2, but3, but4;
   
   private ResourceBundle bn = ResourceBundle.getBundle("ex1",Internacionalizar.local);
	
   public FormaPagamento()
   {
	   setModal(true);
	   setTitle(bn.getString("p92"));
   	
      Container cont1 = getContentPane();
      cont1.setLayout(new GridLayout(2,1));
   	
      pn1 = new JPanel();
      pn1.setLayout(new GridLayout(1,2));		
   	
      pn2 = new JPanel();
      pn2.setLayout(new GridLayout(1,1));		
   			
   	//BOT�ES
      but1 = new JButton(bn.getString("p93"));
      but2 = new JButton(bn.getString("p94"));
      but3 = new JButton(bn.getString("p95"));
      but4 = new JButton(bn.getString("p96"));
   	
   	//A��O AOS BOT�ES
      but1.addActionListener(this);
      but2.addActionListener(this);
      but3.addActionListener(this);
      but4.addActionListener(this);
   	
   		//PAINEL 1
      pn1.add(but1);
      pn1.add(but2);
      pn1.add(but3);
   
      cont1.add(pn1);
   	
   	//PAINEL 2
      pn2.add(but4);
      
      cont1.add(pn2);
      
   	
      setLocation(500,300);
      setSize(525,180);
      setVisible(true);
         
      setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
   	
   }//FIM DO CONTRUTOR
	
   public void actionPerformed(ActionEvent e)
   {
      try
      {
         if(e.getSource() == but1)
         {
         	Dinheiro din = new Dinheiro();
         	this.dispose();
         }
         if(e.getSource() == but2)
         {
         	CartaoCredito cartCred = new CartaoCredito();
         	this.dispose();
         }
         if(e.getSource() == but3)
         {
         	CartaoDebito cartDeb = new CartaoDebito();
         	this.dispose();
         }
         if(e.getSource() == but4)
         {
         	this.dispose();
         }
      	
      }
      catch(Exception ex)
      {
         JOptionPane.showMessageDialog(null,"ERRO");
      }
   }//ActionPerformed
	
   public static void main(String args[])
   {
      FormaPagamento men = new FormaPagamento();
   }
}//FIM DA CLASSE
