package telas;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.util.ResourceBundle;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import dao.ItemPedidoDAO;
import service.ItemPedidoService;

public class FecharConta extends JDialog implements ActionListener {
	
	private JPanel pn1, pn2, pn3, pn4;
	private JLabel lb1, lb2, lb3, lb4,lb5, lb6, lb7;
	private JButton but1, but2, but3, but4, but5;
	private JTextField txt1, txt2, txt3, txt4, txt5, txt6, txt7;
	private ResourceBundle bn = ResourceBundle.getBundle("ex1",Internacionalizar.local);
	public static double total;
	public static DecimalFormat df = new DecimalFormat("####0.00");
	
	
	public FecharConta()
	{
		setModal(true);
		setTitle(bn.getString("p75"));
		
		Container cont1 = getContentPane();
		cont1.setLayout(new GridLayout(4,1));
		
		pn1 = new JPanel();
		pn1.setLayout(new GridLayout(4,2));
		
		pn2 = new JPanel();
		pn2.setLayout(new FlowLayout());
		
		pn3 = new JPanel();
		pn3.setLayout(new GridLayout(4,2));
      
      pn4 = new JPanel();
		pn4.setLayout(new GridLayout(1,3));
		
		//JLABELS
		lb1 = new JLabel(bn.getString("p76"));
		lb2 = new JLabel(bn.getString("p77"));
		lb3 = new JLabel(bn.getString("p78"));
		lb4 = new JLabel(bn.getString("p79"));
//        lb5 = new JLabel(bn.getString("p80"));
        lb6 = new JLabel(bn.getString("p81"));
        lb7 = new JLabel(bn.getString("p82"));
		
		//BOT�ES
		but1 = new JButton(bn.getString("p83"));
//		but2 = new JButton(bn.getString("p84"));
		but3 = new JButton(bn.getString("p85"));
		but4 = new JButton(bn.getString("p86"));
		but5 = new JButton(bn.getString("p87"));
		
		but1.addActionListener(this);
//		but2.addActionListener(this);
		but3.addActionListener(this);
		but4.addActionListener(this);
		but5.addActionListener(this);

		//TEXT FIELDS
		txt1 = new JTextField(10);
		txt2 = new JTextField(10);
		txt3 = new JTextField(10);
		txt4 = new JTextField(10);
//      txt5 = new JTextField(10);
		txt6 = new JTextField(10);
		txt7 = new JTextField(10);

		txt6.setEditable(false);
		txt7.setEditable(false);
		
		
		Action action = new AbstractAction()
		{
		    @Override
		    public void actionPerformed(ActionEvent e)
		    {
		    	ItemPedidoService imod = new ItemPedidoService();
				ItemPedidoDAO idao = new ItemPedidoDAO();
				
				imod.setNumeroPedido(Integer.parseInt(txt4.getText()));
				
				String soma = idao.soma(imod);
				double conta = Double.parseDouble(soma);
				double taxa = Double.parseDouble(idao.soma(imod)) * 0.1;
				total = conta + taxa;
				
				
				txt6.setText("R$ " + df.format(taxa) );
				txt7.setText("R$ " + df.format(total));
		    }
		};
		
		txt4.addActionListener(action);
		
		//PAINEL 1
		pn1.add(lb1);
		pn1.add(txt1);
		pn1.add(lb2);
		pn1.add(txt2);
		pn1.add(lb3);
		pn1.add(txt3);
		pn1.add(but1);
//		pn1.add(but2);
		
		cont1.add(pn1);
		
		//PAINEL 2
		cont1.add(pn2);
		
		//PAINEL 3
		pn3.add(lb4);
		pn3.add(txt4);
//      pn3.add(lb5);
//      pn3.add(txt5);
      pn3.add(lb6);
      pn3.add(txt6);
      pn3.add(lb7);
      pn3.add(txt7);
		
		cont1.add(pn3);
      
      //PAINEL 4
		pn4.add(but3);
		pn4.add(but4);
      pn4.add(but5);
		
		cont1.add(pn4);
		
		setLocation(300,100);
	    setSize(665,600);
	    setVisible(true);
	      
	    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
	}//FIM DO CONTRUTOR
	
	public void actionPerformed(ActionEvent e)
	{
		try
		{
			if(e.getSource() == but1)
			{
				ItemPedidoService imod = new ItemPedidoService();
				ItemPedidoDAO idao = new ItemPedidoDAO();
				imod.setNumeroCardapio(Integer.parseInt(txt2.getText()));
				imod.setNumeroPedido(Integer.parseInt(txt4.getText()));
				imod.setQuantidade(Integer.parseInt(txt3.getText()));
				
				idao.incluir3(imod);
			}
//			if(e.getSource() == but2)
//			{
//				ItemPedidoModel imod = new ItemPedidoModel();
//				ItemPedidoDAO idao = new ItemPedidoDAO();
//				imod.setNumeroCardapio(Integer.parseInt(txt2.getText()));
//				imod.setNumeroPedido(Integer.parseInt(txt4.getText()));
//				
//				idao.excluir(imod);
//				
//			}
			if(e.getSource() == but3)
			{
				this.dispose();
			}
			if(e.getSource() == but4)
			{
				FormaPagamento formPag = new FormaPagamento();
				this.dispose();
			}
         if(e.getSource() == but5)
			{
				EmitirNF emitNF = new EmitirNF();
				this.dispose();
			}
		}
		catch(Exception ex)
		{
			JOptionPane.showMessageDialog(null,"ERRO");
		}
	}//ActionPerformed
	
	public static void main(String args[])
	{
		FecharConta men = new FecharConta();
	}
}//FIM DA CLASSE
