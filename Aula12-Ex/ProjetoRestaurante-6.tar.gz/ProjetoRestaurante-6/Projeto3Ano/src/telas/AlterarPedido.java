package telas;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ResourceBundle;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import service.PedidoService;
import to.PedidoTO;

public class AlterarPedido extends JDialog implements ActionListener {
	
	private JPanel pn1, pn2, pn3;
	private JLabel lb1, lb2, lb3;
	private JButton but1, but2, but3, but4;
	private JTextField txt1, txt2, txt3, txt4, txt5;
	private JTextArea area;
	
	private ResourceBundle bn = ResourceBundle.getBundle("ex1",Internacionalizar.local);
	
	public AlterarPedido()
	{
		setModal(true);
		setTitle(bn.getString("p16"));
		
		Container cont1 = getContentPane();
		cont1.setLayout(new GridLayout(3,1));
		
		pn1 = new JPanel();
		pn1.setLayout(new GridLayout(4,2));
		
		pn2 = new JPanel();
		pn2.setLayout(new FlowLayout());
		
		pn3 = new JPanel();
		pn3.setLayout(new GridLayout(2,2,50,50));
		
		//
		area = new JTextArea();
		
		//JLABELS
		lb1 = new JLabel(bn.getString("p17"));
		lb2 = new JLabel(bn.getString("p18"));
		lb3 = new JLabel(bn.getString("p19"));
		
		//BOT�ES
//		but1 = new JButton(bn.getString("p20"));
//		but2 = new JButton(bn.getString("p21"));
		but3 = new JButton(bn.getString("p22"));
		but4 = new JButton(bn.getString("p23"));
		
//		but1.addActionListener(this);
//		but2.addActionListener(this);
		but3.addActionListener(this);
		but4.addActionListener(this);
		
		//TEXT FIELDS
		txt1 = new JTextField(10);
		txt2 = new JTextField(10);
		txt3 = new JTextField(10);
		txt4 = new JTextField(10);
		txt5 = new JTextField(10);
		
		txt4.setVisible(false);
		txt4.setEditable(false);
		txt5.setVisible(false);
		txt5.setVisible(false);
		
		//PAINEL 1
		pn1.add(lb1);
		pn1.add(txt1);
		pn1.add(lb2);
		pn1.add(txt2);
		pn1.add(lb3);
		pn1.add(txt3);
//		pn1.add(but2);
//		pn1.add(but1);
		
		cont1.add(pn1);
		
		//PAINEL 2
		pn2.add(area);
		cont1.add(pn2);
		
		//PAINEL 3
		pn3.add(txt4);
		pn3.add(txt5);
		pn3.add(but3);
		pn3.add(but4);
		
		cont1.add(pn3);
		
		setLocation(500,300);
	    setSize(665,600);
	    setVisible(true);
	      
	    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
	}//FIM DO CONTRUTOR
	
	public void actionPerformed(ActionEvent e)
	{
		try
		{
//			if(e.getSource() == but1)
//			{
//				
//			}
//			if(e.getSource() == but2)
//			{
//				
//			}
			if(e.getSource() == but3)
			{
				this.dispose();
			}
			if(e.getSource() == but4)
			{
				PedidoService pod = new PedidoService();
//				PedidoDAO pdao = new PedidoDAO();
				PedidoTO to = new PedidoTO();
				
				to.setNumero(Integer.parseInt(txt1.getText()));
				to.setMesa(Integer.parseInt(txt2.getText()));
				to.setGarcom(txt3.getText());

				pod.consultar3(to);

				area.setText("N�mero: " + to.getNumero() + " Mesa: " + to.getMesa() + "\n Data Entrada: "
						+ to.getEntrada() + "\n Data Sa�da: " + to.getSaida() + "\n Gar�om: " + to.getGarcom() + "\n\n");
				
				to.setNumero(Integer.parseInt(txt1.getText()));
				to.setMesa(Integer.parseInt(txt2.getText()));
				to.setGarcom(txt3.getText());
				
				pod.alterar(to);
				pod.consultar3(to);
				
				area.append("ALTERADO PARA\nN�mero: " + to.getNumero() + " Mesa: " + to.getMesa() + "\n Data Entrada: "
						+ to.getEntrada() + "\n Data Sa�da: " + to.getSaida() + "\n Gar�om: " + to.getGarcom());
			}
		}
		catch(Exception ex)
		{
			JOptionPane.showMessageDialog(null,"ERRO");
		}
	}//ActionPerformed
	
	public static void main(String args[])
	{
		AlterarPedido men = new AlterarPedido();
	}
}//FIM DA CLASSE
