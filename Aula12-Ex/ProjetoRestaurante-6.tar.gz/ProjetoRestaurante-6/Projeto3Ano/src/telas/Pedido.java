package telas;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ResourceBundle;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Pedido extends JDialog implements ActionListener {
	
   //private JPanel pn1, pn2;
   private JButton but1, but2, but3, but4, but5, but6;
   private ResourceBundle bn = ResourceBundle.getBundle("ex1",Internacionalizar.local);
	
   public Pedido()
   {
	   setModal(true);
      setTitle(bn.getString("p0"));
   	
      Container cont1 = getContentPane();
      cont1.setLayout(new GridLayout(3,2));
   		
   			
   	//BOT�ES
      but1 = new JButton(bn.getString("p1"));
      but2 = new JButton(bn.getString("p2"));
      but3 = new JButton(bn.getString("p3"));
      but4 = new JButton(bn.getString("p4"));
      but5 = new JButton(bn.getString("p5"));
      but6 = new JButton(bn.getString("p6"));
   	
   	//A��O AOS BOT�ES
      but1.addActionListener(this);
      but2.addActionListener(this);
      but3.addActionListener(this);
      but4.addActionListener(this);
      but5.addActionListener(this);
      but6.addActionListener(this);
   	
   		//PAINEL 1
      cont1.add(but1);
      cont1.add(but2);
      cont1.add(but3);
      cont1.add(but4);
      cont1.add(but5);
      cont1.add(but6);

      
   	
      setLocation(500,300);
      setSize(390,180);
      setVisible(true);
         
      setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
   	
   }//FIM DO CONTRUTOR
	
   public void actionPerformed(ActionEvent e)
   {
      try
      {
         if(e.getSource() == but1)
         {
        	 FazerPedido fazPed = new FazerPedido();
         }
         if(e.getSource() == but2)
         {
        	 ConsultarPedido consPed = new ConsultarPedido();
         }
         if(e.getSource() == but3)
         {
         	PriorizarPedido priPed = new PriorizarPedido();
         }
         if(e.getSource() == but4)
         {
         	AlterarPedido altPed = new AlterarPedido();
         }
         if(e.getSource() == but5)
         {
         	RemoverPedido remPed = new RemoverPedido();
         }
         if(e.getSource() == but6)
         {
        	 this.dispose();
         }
      	
      }
      catch(Exception ex)
      {
         JOptionPane.showMessageDialog(null,"ERRO");
      }
   }//ActionPerformed
	
   public static void main(String args[])
   {
      Pedido tela2 = new Pedido();
   }
}//FIM DA CLASSE
