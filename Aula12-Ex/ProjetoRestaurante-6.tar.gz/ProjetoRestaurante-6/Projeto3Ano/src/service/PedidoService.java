package service;

import dao.PedidoDAO;
import to.CardapioTO;
import to.PedidoTO;

public class PedidoService {

	private PedidoDAO dao;
	
	public PedidoService()
	{
		dao = new PedidoDAO();
	}
	
	//SERVICES
		public void criar(PedidoTO to)
		{
			dao.incluir(to);
		}
		
		public void alterar(PedidoTO to)
		{
			dao.alterar(to);
		}
		
		public void excluir(PedidoTO to)
		{

			dao.excluir(to);
		}
		
		public PedidoTO consultar(PedidoTO to)
		{
			return dao.consultar(to);
		}
		
		public int consultar2(PedidoTO to)
		{
			return dao.consultar2(to);
		}
		
		public PedidoTO consultar3(PedidoTO to)
		{
			return dao.consultar3(to);
		}
	
	
	
}
