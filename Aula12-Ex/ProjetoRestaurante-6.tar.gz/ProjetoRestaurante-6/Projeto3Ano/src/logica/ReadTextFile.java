package logica;
// This program reads a text file and displays each record.
import java.io.File;
import java.io.FileNotFoundException;
import java.lang.IllegalStateException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class ReadTextFile
{
   public Scanner input;
   public String texto="";
   
   // enable user to open file
   public void openFile()
   {
      try
      {
         input = new Scanner( new File( "decifra.txt" ) );
      }// end try
      
      catch ( FileNotFoundException fileNotFoundException )
      {
         System.err.println( "Erro ao abrir o arquivo." );
         System.exit( 1 );
      }// end catch
   } // end method openFile

   // read record from file
   public String readRecords()
   { // object to be written to screen
      
      try // read records from file using Scanner object
      {
         while ( input.hasNext() )
         {
            texto = texto+input.next();// read text
         }        
      } // end try
      
      catch ( NoSuchElementException elementException )
      {
         System.err.println( "Arquivo Corrompido." );
         input.close();
         System.exit( 1 );
         
      } // end catch
      
      catch ( IllegalStateException stateException )
      {
         System.err.println( "Erro ao ler o arquivo." );
         System.exit( 1 );
      } // end catch
      
      //return record;
      return texto;
   } // end method readRecords
   
   // close file and terminate application
   public void closeFile()
   {
      if ( input != null )
         input.close(); // close file
   } // end method closeFile
} // end class ReadTextFile