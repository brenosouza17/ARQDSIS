package dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import banco.ConnectionFactory;
import to.CardapioTO;



public class CardapioDAO {
	

		

	    public CardapioDAO() {
			// TODO Auto-generated constructor stub
		}
	   
	    
	    public void incluir(CardapioTO ca)
	    {
	    	String sql = "insert into CARDAPIO values (?,?,?,1)";
	    	
	    	try
	    	{
		    	Connection con =  ConnectionFactory.obtemConexao();
		    	PreparedStatement prep = con.prepareStatement(sql);
		    	prep.setInt(1,ca.getNumero());
		    	prep.setDouble(2,ca.getValorUnit());
		    	prep.setString(3,ca.getDescricao());
		    	
		    	System.out.println(prep.toString());
		    	prep.execute();
		    	prep.close();
	    	}
	    	 catch (Exception e) 
	        { 
	           e.printStackTrace(); 
	           
	        }
	    }
	    
	    	public CardapioTO consultar(CardapioTO ca) 
	    	   { 
    	      String sqlSelect = "SELECT * FROM CARDAPIO WHERE numero = ?"; 
	    	   
	    	      PreparedStatement stm = null; 
	    	      ResultSet rs = null;
	    	      try
	    	      {
	    	    	 Connection conn =  ConnectionFactory.obtemConexao();
	    	         stm  = conn.prepareStatement(sqlSelect);
	    	         stm.setInt(1, ca.getNumero());
	    	         rs  = stm.executeQuery();
	    	         if (rs.next())
	    	         {
	    	        	ca.setNumero(rs.getInt("numero"));
	    	            ca.setDescricao(rs.getString("descricao"));
	    	            ca.setValorUnit(rs.getDouble("valor_unitario"));
	    	            ca.setDispPrato(rs.getBoolean("disponibilidade_do_prato"));
	    	         }
	    	         stm.close();
	    	      }
	    	      catch(Exception e)
	    	      {
	    	         e.printStackTrace(); 
	    	      }
	    	      return ca;
	    	
	    	
	    }
	    	
	    	public void excluir(CardapioTO ca)
	    	{
	    		String sql = "delete from CARDAPIO where numero = ?";
	    		
	    		try
		    	{
			    	Connection con =  ConnectionFactory.obtemConexao();
			    	PreparedStatement prep = con.prepareStatement(sql);
			    	prep.setInt(1,ca.getNumero());
			    	
			    	System.out.println(prep.toString());
			    	prep.execute();
			    	prep.close();
		    	}
		    	 catch (Exception e) 
		        { 
		           e.printStackTrace(); 
		           
		        }
	    	}
	    	
	    	public void alterar(CardapioTO ca)
	    	{
	    		String sql = "update CARDAPIO set descricao = ?, valor_unitario = ? where numero = ?";
	    		
	    		try
		    	{
			    	Connection con =  ConnectionFactory.obtemConexao();
			    	PreparedStatement prep = con.prepareStatement(sql);
			    	prep.setString(1,ca.getDescricao());
			    	prep.setDouble(2,ca.getValorUnit());
			    	prep.setInt(3,ca.getNumero());
			    	
			    	System.out.println(prep.toString());
			    	prep.execute();
			    	prep.close();
		    	}
		    	 catch (Exception e) 
		        { 
		           e.printStackTrace(); 
		           
		        }
	    		
	    		
	    	}
	}


