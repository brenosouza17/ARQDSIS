package utils;

import java.io.BufferedReader;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;
import org.json.JSONObject;

import to.CardapioTO;


public class JSONUtils {
	
	public static  String montaJSON (HttpServletRequest request) throws IOException{
		BufferedReader reader = request.getReader();
		StringBuilder sb = new StringBuilder();
		String linha;
		while ((linha = reader.readLine()) != null) {
			sb.append(linha);
		}
		return sb.toString();
	}
	
	public static CardapioTO jSONToChamado (String json) throws IOException {
		try {
			JSONObject jsonObject = new JSONObject(json);
			int numero = jsonObject.getInt("numero");
			String desc = jsonObject.getString("descricao");
			double valUnit = jsonObject.getDouble("valorUnit");
			boolean dispPrato = jsonObject.getBoolean("dispPrato");
			CardapioTO cardapio = new CardapioTO (numero, desc, valUnit, dispPrato);
			return cardapio;
		}
		catch (JSONException e) {
			throw new IOException (e);
		}
		
	}
	
	public static String chamadoToJSON (CardapioTO cardapio) throws IOException{
		try {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("numero", cardapio.getNumero());
			jsonObject.put("descricao", cardapio.getDescricao());
			jsonObject.put("valorUnit", cardapio.getValorUnit());
			jsonObject.put("dispPrato", cardapio.isDispPrato());
			return jsonObject.toString();
		}
		catch (JSONException e) {
			throw new IOException (e);
		}
	}
}
